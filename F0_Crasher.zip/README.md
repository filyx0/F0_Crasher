# F0_Crasher

- Extract "KiddionsCrasher"
- Start "start.bat"
- Paste the Kiddions Moddest Menu Scripts Path (KiddionsPath/scripts)
- Wait

---