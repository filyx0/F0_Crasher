import os
import shutil
from colorama import init, Fore, Back, Style
import time

init(convert=True)

def cp(msg):
    print(Fore.RED + "[F0_Crasher] " + Fore.RESET + msg)

cdir = os.path.dirname(__file__)

cp("Starting F0_Crasher Installer: " + cdir)

kpath = input(Fore.RED + "[F0_Crasher] " + Fore.RESET + "Kiddions Path (KiddinsPath/scripts): ")

cp("Copying Files: " + kpath)

shutil.copy(cdir + "\\files\\F0_CrasherObf.lua", kpath)

cp("Done, File Copied: " + kpath)

time.sleep(2.5)

cp("Closing F0_Crasher Installer...")

time.sleep(1)